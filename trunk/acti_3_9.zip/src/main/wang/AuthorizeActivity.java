package main.wang;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;

public class AuthorizeActivity extends Activity {
	OAuth auth;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.authorize);
        
        LinearLayout layout=(LinearLayout)findViewById(R.id.layout);
        //�����Զ���Ӧ
        AndroidHelper.AutoBackground(this, layout, R.drawable.bg, R.drawable.bg);
        
        //����dialog�ļ�����
        OnClickListener ocl = new OnClickListener(){

			public void onClick(DialogInterface dialog, int which) {
				// TODO Auto-generated method stub
				String CallBackUrl = "myapp://AuthorizeActivity";
				auth=new OAuth();
                auth.RequestAccessToken(AuthorizeActivity.this, CallBackUrl);
			}
        	
        };
        //����dialog
        Dialog dialog = new AlertDialog.Builder(this)
        .setMessage("��һ��ʹ����Ҫ������������΢���˺ź�������е�¼��Ȩ")
        .setPositiveButton("��ʼ", ocl).create();
        dialog.show();
        
        }
    @Override
    protected void onNewIntent(Intent intent) {
            super.onNewIntent(intent);
            Log.v("xxxxxintent","aaaaaaaaccept");
            //�����ﴦ����ȡ���ص�oauth_verifier����
            UserInfo user= auth.GetAccessToken(intent);

            if(user!=null){
                        DataHelper helper=new DataHelper(this);
                        String uid=user.getUserId();
                        if(helper.HaveUserInfo(uid))
                        {
                            helper.UpdateUserInfo(user);
                            Log.e("UserInfo", "update");
                        }else
                        {
                            helper.SaveUserInfo(user);
                            Log.e("UserInfo", "add");
                        }
                    }
            
    }
}