package main.wang;

import java.util.List;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.AdapterView.OnItemClickListener;

public class Login extends Activity {
	DataHelper dbHelper;
	Dialog dialog;
	List<UserInfo> userList;
	ImageView icon;
	EditText iconSelect;
	String Select_Name; 
	 protected void onStop() {
         //���SharedPreferences����
         SharedPreferences MyPreferences = getSharedPreferences(Select_Name, Activity.MODE_PRIVATE);
         //���SharedPreferences.Editor����
         SharedPreferences.Editor editor = MyPreferences.edit();
         //��������е�ֵ
         editor.putString("name", iconSelect.getText().toString());
         editor.commit();
         super.onStop();
     }
	
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.userinfo);
		initUser();
		ImageButton iconSelectBtn = (ImageButton) findViewById(R.id.iconSelectBtn);
		iconSelect =(EditText)this.findViewById(R.id.iconSelect);
		iconSelectBtn.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub
				View diaView = View.inflate(Login.this, R.layout.dialog2, null);
				dialog = new Dialog(Login.this, R.style.dialog2);
				dialog.setContentView(diaView);
				dialog.show();
				if(userList==null)
				{
					Log.v("userList","null");
				}
				UserAdapater adapater = new UserAdapater(userList,Login.this);
                ListView listview=(ListView)diaView.findViewById(R.id.list);
                listview.setVerticalScrollBarEnabled(false);// ListViewȥ��������
                listview.setAdapter(adapater);
                listview.setOnItemClickListener(new OnItemClickListener(){
                    public void onItemClick(AdapterView<?> arg0, View view,int arg2, long arg3) {
                        TextView tv=(TextView)view.findViewById(R.id.showName);           
                        iconSelect.setText(tv.getText());
                        ImageView iv=(ImageView)view.findViewById(R.id.icon);
                        icon.setImageDrawable(iv.getDrawable());
                        dialog.dismiss();
                    }
                    
                });
			}

		});
	}

	private void initUser() {
		// ��ȡ�˺��б�
		dbHelper = new DataHelper(this);
		userList = dbHelper.GetUserList(false);
		if (userList.isEmpty()) {
			Intent intent = new Intent();
			intent.setClass(Login.this, AuthorizeActivity.class);
			startActivity(intent);
		} else {
			SharedPreferences preferences = getSharedPreferences(Select_Name,Activity.MODE_PRIVATE);
			String str = preferences.getString("name", "");
			UserInfo user = null;
			if (str != "") {
				user = getUserByName(str);
			}
			if (user == null) {
				Log.v("user","null");
				user = userList.get(0);
			}

			icon.setImageDrawable(user.getUserIcon());
			iconSelect.setText(user.getUserName());
		}}

	public UserInfo getUserByName(String name) {
		for (UserInfo u : userList) {
			if (u.getUserName().equals(name)) {
				return u;
			}
		}
		return null;
	}
	
	
	private void GoHome(){
        if(userList!=null)
        {
            String name=iconSelect.getText().toString();
            UserInfo u=getUserByName(name);
            if(u!=null)
            {
                ConfigHelper.nowUser=u;//��ȡ��ǰѡ����û����ұ���
            }
        }
        if(ConfigHelper.nowUser!=null)
        {
                        //�����û���ҳ
            Intent intent = new Intent();
                    intent.setClass(Login.this, Main.class);
                    startActivity(intent);
        }
    }
	
	
	
	
	public static class ConfigHelper {
		public static UserInfo nowUser;
		}
	
	
	
}