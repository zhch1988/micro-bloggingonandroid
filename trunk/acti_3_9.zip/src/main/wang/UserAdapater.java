package main.wang;
import java.util.List;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class UserAdapater extends BaseAdapter{
	List<UserInfo> userList;
	Activity act;
        public UserAdapater(List<UserInfo> userList ,Activity act) {
		super();
		// TODO Auto-generated constructor stub
		this.userList = userList;
		this.act = act;
	}

		public int getCount() {
            return userList.size();
        }

        public Object getItem(int position) {
            return userList.get(position);
        }

        public long getItemId(int position) {
            return position;
        }

        public View getView(int position, View convertView, ViewGroup parent) {
            convertView = LayoutInflater.from(act.getApplicationContext()).inflate(R.layout.login_item, null);

            ImageView iv = (ImageView) convertView.findViewById(R.id.icon);
            TextView tv = (TextView) convertView.findViewById(R.id.showName);
            UserInfo user = userList.get(position);
            try {
                //����ͼƬ��ʾ
                iv.setImageDrawable(user.getUserIcon());
                //������Ϣ
                tv.setText(user.getUserName());

                
            } catch (Exception e) {
                e.printStackTrace();
            }
            return convertView;
        }

	}