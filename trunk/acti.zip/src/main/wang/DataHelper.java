package main.wang;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import oauth.signpost.http.HttpResponse;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.util.Log;

public class DataHelper {
    //���ݿ�����
    private static String DB_NAME = "mysinaweibo.db";
    //���ݿ�汾
    private static int DB_VERSION = 2;
    private SQLiteDatabase db;
    private SqliteHelper dbHelper;
    
    public DataHelper(Context context){
        dbHelper=new SqliteHelper(context,DB_NAME, null, DB_VERSION);
        db= dbHelper.getWritableDatabase();
    }
    
    public void Close()
    {
        db.close();
        dbHelper.close();
    }
    //��ȡusers���е�UserID��Access Token��Access Secret�ļ�¼
    public List<UserInfo> GetUserList(Boolean isSimple)
    {
        List<UserInfo> userList = new ArrayList<UserInfo>();
        Cursor cursor=db.query(SqliteHelper.TB_NAME, null, null, null, null, null, UserInfo.ID+" DESC");
        cursor.moveToFirst();
        while(!cursor.isAfterLast()&& (cursor.getString(1)!=null)){
            UserInfo user=new UserInfo();
            user.setId(cursor.getString(0));
            user.setUserId(cursor.getString(1));
            user.setToken(cursor.getString(2));
            user.setTokenSecret(cursor.getString(3));
            if(!isSimple){
            user.setUserName(cursor.getString(4));
            ByteArrayInputStream stream = new ByteArrayInputStream(cursor.getBlob(5)); 
            Drawable icon= Drawable.createFromStream(stream, "image");
            user.setUserIcon(icon);
            }
            userList.add(user);
            cursor.moveToNext();
        }
        cursor.close();
        return userList;
    }
    
    //�����û�ͷ����Ϣ���ǳ�
    public List<Map<String, Object>> getLoginList() {
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>(2);
		Map<String, Object> map;
		
		Cursor cursor=db.query(SqliteHelper.TB_NAME, null, null, null, null, null, UserInfo.ID+" DESC");
        cursor.moveToFirst();
        while(!cursor.isAfterLast()&& (cursor.getString(1)!=null)){
        	map = new HashMap<String, Object>();
        	map.put("UserName", cursor.getString(4));
        	//ת��ͼƬ
        	ByteArrayInputStream stream = new ByteArrayInputStream(cursor.getBlob(5));
        	Drawable icon= Drawable.createFromStream(stream, "image");
			map.put("UserIcon", icon);
			list.add(map);
	        cursor.moveToNext();
			}
        cursor.close();      
		return list;
	}
    
    //�ж�users���е��Ƿ����ĳ��UserID�ļ�¼
    public Boolean HaveUserInfo(String UserId)
    {
        Boolean b=false;
        Cursor cursor=db.query(SqliteHelper.TB_NAME, null, UserInfo.USERID + "=" + UserId, null, null, null,null);
        b=cursor.moveToFirst();
        Log.e("HaveUserInfo",b.toString());
        cursor.close();
        return b;
    }
    
    //����users���ļ�¼������UserId�����û��ǳƺ��û�ͼ��
    public int UpdateUserInfo(String userName,Bitmap userIcon,String UserId)
    {
        ContentValues values = new ContentValues();
        values.put(UserInfo.USERNAME, userName);
        // BLOB����  
        final ByteArrayOutputStream os = new ByteArrayOutputStream();  
        // ��Bitmapѹ����PNG���룬����Ϊ100%�洢          
        userIcon.compress(Bitmap.CompressFormat.PNG, 100, os);   
        // ����SQLite��Content��������Ҳ����ʹ��raw  
        values.put(UserInfo.USERICON, os.toByteArray());
        int id= db.update(SqliteHelper.TB_NAME, values, UserInfo.USERID + "=" + UserId, null);
        Log.e("UpdateUserInfo2",id+"");
        return id;
    }
    
    //��api��ȡͷ��
    public void UpdateUserInfo(Context context,List<UserInfo> userList){
    	DataHelper dbHelper=new DataHelper(context);
    	OAuth auth=new OAuth();
    	String url = "http://api.t.sina.com.cn/users/show.json";
    	Log.e("userCount", userList.size()+"");
    	for(UserInfo user:userList){
    	if(user!=null)
    	{
    	List params=new ArrayList();
    	params.add(new BasicNameValuePair("source", auth.consumerKey)); 
    	params.add(new BasicNameValuePair("user_id", user.getUserId())); 
    	HttpResponse response =(HttpResponse) auth.SignRequest(user.getToken(), user.getTokenSecret(), url, params);
    	if (200 == response.getStatusLine().getStatusCode()){
    	try {
    	InputStream is =  response.getEntity().getContent();
    	Reader reader = new BufferedReader(new InputStreamReader(is), 4000);
    	StringBuilder buffer = new StringBuilder((int) response.getEntity().getContentLength());
    	try {
    	char[] tmp = new char[1024];
    	int l;
    	while ((l = reader.read(tmp)) != -1) {
    	buffer.append(tmp, 0, l);
    	}
    	} finally {
    	reader.close();
    	}
    	String string = buffer.toString();
    	response.getEntity().consumeContent();
    	JSONObject data = new JSONObject(string);
    	String ImgPath= data.getString("profile_image_url");
    	Bitmap userIcon= DownloadImg(ImgPath);

    	String userName=data.getString("screen_name");
    	dbHelper.UpdateUserInfo(userName, userIcon, user.getUserId());
    	Log.e("ImgPath", ImgPath);

    	}catch (IllegalStateException e) {
    	e.printStackTrace();
    	} catch (IOException e) {
    	e.printStackTrace();
    	} catch (JSONException e) {
    	e.printStackTrace();
    	} 
    	}
    	}
    	}
    	dbHelper.Close();
    	}

    
    //����users���ļ�¼
    public int UpdateUserInfo(UserInfo user)
    {
        ContentValues values = new ContentValues();
        values.put(UserInfo.USERID, user.getUserId());
        values.put(UserInfo.TOKEN, user.getToken());
        values.put(UserInfo.TOKENSECRET, user.getTokenSecret());
        int id= db.update(SqliteHelper.TB_NAME, values, UserInfo.USERID + "=" + user.getUserId(), null);
        Log.e("UpdateUserInfo",id+"");
        return id;
    }
    
    //����users���ļ�¼
    public Long SaveUserInfo(UserInfo user)
    {
        ContentValues values = new ContentValues();
        values.put(UserInfo.USERID, user.getUserId());
        values.put(UserInfo.TOKEN, user.getToken());
        values.put(UserInfo.TOKENSECRET, user.getTokenSecret());
        Long uid = db.insert(SqliteHelper.TB_NAME, UserInfo.ID, values);
        Log.e("SaveUserInfo",uid+"");
        return uid;
    }
    
    //ɾ��users���ļ�¼
    public int DelUserInfo(String UserId){
        int id=  db.delete(SqliteHelper.TB_NAME, UserInfo.USERID +"="+UserId, null);
        Log.e("DelUserInfo",id+"");
        return id;
    }
}
