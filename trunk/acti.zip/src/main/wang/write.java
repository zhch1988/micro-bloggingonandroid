package main.wang;
import android.app.Activity;
import android.os.Bundle;
public class write extends Activity{
   @Override
public void onCreate( Bundle savedInstanceState){
	   super.onCreate(savedInstanceState);
	   this.setContentView(R.layout.write);
	   
   }
}
