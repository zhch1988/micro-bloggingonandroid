package main.wang;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.util.ArrayList;
import java.util.List;

import main.wang.R;
import oauth.signpost.http.HttpResponse;

import org.apache.http.message.BasicNameValuePair;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.widget.LinearLayout;

public class UI_welcome_Activity extends Activity {
	DataHelper dbHelper;
    /** Called when the activity is first created. 
     * @throws InterruptedException */
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.welcome);
        LinearLayout layout=(LinearLayout)findViewById(R.id.layout);
        //�����Զ���Ӧ
        AndroidHelper.AutoBackground(this, layout, R.drawable.bg, R.drawable.bg);
      //��ȡ�˺��б�
        dbHelper=new DataHelper(this);
        List<UserInfo> userList= dbHelper.GetUserList(true);
        if(userList.isEmpty())//���Ϊ��˵����һ��ʹ������AuthorizeActivityҳ�����OAuth��֤
        {
        	Log.v("userList", "empty");
               Intent intent = new Intent();
               intent.setClass(UI_welcome_Activity.this, AuthorizeActivity.class);
               startActivity(intent);
        }
        else//�����Ϊ�ն�ȡ��Щ��¼��UserID�š�Access Token��Access Secretֵ
            //Ȼ�������3��ֵ�������˵�api�ӿڻ�ȡ��Щ��¼��Ӧ���û��ǳƺ��û�ͷ��ͼ�����Ϣ��
        {
        	Log.v("userList", "NOT empty");
            Intent intent = new Intent();
            intent.setClass(UI_welcome_Activity.this, login.class);
            startActivity(intent);
        }
    }
    
//    public void UpdateUserInfo(Context context,List<UserInfo> userList){
//    	DataHelper dbHelper=new DataHelper(context);
//    	OAuth auth=new OAuth();
//    	String url = "http://api.t.sina.com.cn/users/show.json";
//    	Log.e("userCount", userList.size()+"");
//    	for(UserInfo user:userList){
//    	if(user!=null)
//    	{
//    	List params=new ArrayList();
//    	params.add(new BasicNameValuePair("source", auth.consumerKey)); 
//    	params.add(new BasicNameValuePair("user_id", user.getUserId())); 
//    	HttpResponse response =(HttpResponse) auth.SignRequest(user.getToken(), user.getTokenSecret(), url, params);
//    	if (200 == ((org.apache.http.HttpResponse) response).getStatusLine().getStatusCode()){
//    	try {
//    	InputStream is = ((org.apache.http.HttpResponse) response).getEntity().getContent();
//    	Reader reader = new BufferedReader(new InputStreamReader(is), 4000);
//    	StringBuilder buffer = new StringBuilder((int) ((org.apache.http.HttpResponse) response).getEntity().getContentLength());
//    	try {
//    	char[] tmp = new char[1024];
//    	int l;
//    	while ((l = reader.read(tmp)) != -1) {
//    	buffer.append(tmp, 0, l);
//    	}
//    	} finally {
//    	reader.close();
//    	}
//    	String string = buffer.toString();
//    	((org.apache.http.HttpResponse) response).getEntity().consumeContent();
//    	JSONObject data = new JSONObject(string);
//    	String ImgPath= data.getString("profile_image_url");
//    	Bitmap userIcon= DownloadImg(ImgPath);
//
//    	String userName=data.getString("screen_name");
//    	dbHelper.UpdateUserInfo(userName, userIcon, user.getUserId());
//    	Log.e("ImgPath", ImgPath);
//
//    	}catch (IllegalStateException e) {
//    	e.printStackTrace();
//    	} catch (IOException e) {
//    	e.printStackTrace();
//    	} catch (JSONException e) {
//    	e.printStackTrace();
//    	} 
//    	}
//    	}
//    	}
//    	dbHelper.Close();
//    	}
    
    
}