package main.wang;
import android.app.Activity;
import android.os.Bundle;
import android.widget.SimpleAdapter;
import android.widget.Spinner;
public class login extends Activity {
	DataHelper dbHelper;
	 public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.userinfo);
	        Spinner s = (Spinner) findViewById(R.id.iconSelect);
	        dbHelper = new DataHelper(this);
	        SimpleAdapter adapter = new SimpleAdapter(this, dbHelper.getLoginList(),
					R.layout.login_item,
					new String[] { "UserName", "UserIcon" }, new int[] {
							R.id.useraccount, R.id.icon });
	        s.setAdapter(adapter);
	        
	
}
}
